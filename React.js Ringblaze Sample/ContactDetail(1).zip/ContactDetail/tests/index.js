import { mapDispatchToProps } from '../index';

describe('<ContactDetail />', () => {
  describe('mapDispatchToProps', () => {
    describe('dispatch', () => {
      it('should be injected', () => {
        const dispatch = jest.fn();
        const result = mapDispatchToProps(dispatch);
        expect(result.dispatch).toBeDefined();
      });
    });
  });
});
