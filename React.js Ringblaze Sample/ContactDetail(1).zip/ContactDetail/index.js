/*
 *
 * ContactDetailContainer
 *
 */

import { connect } from 'react-redux';

import ContactDetail from 'components/ContactDetail';

export function mapDispatchToProps(dispatch) {
  return {
    dispatch,
  };
}

export default connect(null, mapDispatchToProps)(ContactDetail);
