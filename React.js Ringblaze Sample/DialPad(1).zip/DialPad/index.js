/*
 *
 * DialPadContainer
 *
 */

import { graphql } from 'react-apollo';
import DialPad from 'components/DialPad';

import getPhoneNumber from '../RingblazeNumber/getPhoneNumberQuery.graphql';

export default graphql(getPhoneNumber, { name: 'getPhoneNumber' })(DialPad);
