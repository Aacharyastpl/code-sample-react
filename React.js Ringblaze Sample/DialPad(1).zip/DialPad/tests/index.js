import React from 'react';
import { ApolloProvider } from 'react-apollo';
import { shallow } from 'enzyme';

import DialPad from '../index';

describe('<Dialpad />', () => {
  it('should render without crashing', () => {
    shallow(
      <ApolloProvider client={jest.fn()}>
        <DialPad />
      </ApolloProvider>
    );
  });
});
